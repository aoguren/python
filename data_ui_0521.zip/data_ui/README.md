# 质检数据查看工具

基于浏览器的质检数据查看工具，用于查看Excel文件中的质检数据。

## 运行方式

```bash
# 方式1: 使用Python内置服务器（推荐）
python run_server.py

# 方式2: 使用VS Code的Live Server插件
# 直接在index.html上右键选择"Open with Live Server"
```

## 访问地址

- http://localhost:8080 （使用run_server.py）
- http://localhost:51841 （使用其他服务器）

## 文件说明

| 文件 | 说明 |
|------|------|
| index.html | 主页面，包含所有HTML/CSS/JS |
| build_excel.py | Excel测试数据生成脚本 |
| run_server.py | 本地服务器启动脚本 |
| 质检数据.xlsx | 测试用Excel数据文件 |

## 功能列表

- 文档切换（左侧边栏10个文档）
- 行数据卡片展示（10个字段对）
- 展开/收起/导航/保存
- 批量操作（全部展开/收起/保存）
- 导出已保存数据（CSV格式）

## 数据生成

如需重新生成测试数据：

```bash
python build_excel.py
```

## 相关文档

- [设计文档](docs/superpowers/specs/2026-05-16-质检数据查看工具-design.md)