import pandas as pd
import random

# 设置随机种子以便复现
random.seed(42)

# 定义10个业务字段
fields = [
    "合同号",
    "里程碑",
    "验收条款",
    "项目名称",
    "客户名称",
    "金额",
    "日期",
    "状态",
    "负责人",
    "备注"
]

# 生成质检规则
def generate_quality_check(field_name, value):
    """根据字段值生成质检结果"""
    if value is None or value == "":
        return "缺失"
    if field_name == "金额":
        try:
            if float(value) < 0:
                return "异常-负数"
            return "合格"
        except:
            return "异常-格式错误"
    if field_name == "日期":
        if len(str(value)) != 8:
            return "异常-格式错误"
        return "合格"
    if field_name == "状态":
        if value not in ["进行中", "已完成", "待处理", "已取消"]:
            return "异常-非法值"
        return "合格"
    # 默认规则：非空即合格
    return "合格"

# 生成file_name数据
# 设定10个不同的file_name，每个约有10行，但值不完全相同
file_names = [
    "项目文档_001", "项目文档_002", "项目文档_003", "项目文档_004", "项目文档_005",
    "项目文档_006", "项目文档_007", "项目文档_008", "项目文档_009", "项目文档_010"
]

# 生成100行数据
data = []
for i in range(100):
    # file_name重复模式：每10行重复同一个file_name，但同一file_name下的其它字段值不同
    file_name = file_names[i // 10]

    row = {"file_name": file_name}

    for field in fields:
        # 根据字段类型生成不同的值
        if field == "合同号":
            value = f"HT-{random.randint(20200001, 20259999)}"
        elif field == "里程碑":
            milestones = ["需求确认", "设计完成", "开发完成", "测试通过", "上线完成"]
            value = random.choice(milestones)
        elif field == "验收条款":
            terms = ["条款A", "条款B", "条款C", "条款D", "条款E"]
            value = random.choice(terms)
        elif field == "项目名称":
            projects = ["智慧城市", "数字政务", "工业互联网", "智慧医疗", "智慧教育"]
            value = random.choice(projects)
        elif field == "客户名称":
            customers = ["北京科技公司", "上海实业集团", "广州贸易公司", "深圳创新企业", "杭州互联网公司"]
            value = random.choice(customers)
        elif field == "金额":
            value = round(random.uniform(10000, 5000000), 2)
        elif field == "日期":
            value = f"2024{random.randint(1,12):02d}{random.randint(1,28):02d}"
        elif field == "状态":
            statuses = ["进行中", "已完成", "待处理", "已取消"]
            value = random.choice(statuses)
        elif field == "负责人":
            names = ["张三", "李四", "王五", "赵六", "钱七", "孙八", "周九", "吴十"]
            value = random.choice(names)
        elif field == "备注":
            notes = ["紧急", "正常", "需跟进", "待确认", "已完成", ""]
            value = random.choice(notes)

        row[field] = value
        # 添加质检字段
        row[f"{field}_质检"] = generate_quality_check(field, value)

    data.append(row)

# 创建DataFrame
df = pd.DataFrame(data)

# 调整列顺序：file_name在前，然后是字段1,字段1质检,字段2,字段2质检...
columns = ["file_name"]
for field in fields:
    columns.append(field)
    columns.append(f"{field}_质检")

df = df[columns]

# 保存到Excel
output_path = "E:/project/ai_project/data_ui/质检数据.xlsx"
df.to_excel(output_path, index=False, engine='openpyxl')

print(f"Excel文件已生成：{output_path}")
print(f"共 {len(df)} 行数据，{len(df.columns)} 列")
print(f"\n字段列表：{list(df.columns)}")
print(f"\n前5行数据：")
print(df.head().to_string())