"""LLM 兜底判定器"""
from dataclasses import dataclass
from typing import Optional
import requests
import json


@dataclass
class CompareResult:
    """比较结果"""
    is_match: bool
    method: str
    score: Optional[float] = None
    reason: Optional[str] = None


class LLMJudgeComparator:
    """LLM 兜底判定器"""

    def __init__(
        self,
        api_url: str,
        model_name: str,
        api_key: str = "",
        timeout: int = 30
    ):
        self.api_url = api_url
        self.model_name = model_name
        self.api_key = api_key
        self.timeout = timeout

    def compare(self, man: str, model: str) -> CompareResult:
        """
        使用 LLM 判定两个答案是否语义一致
        """
        try:
            headers = {}
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"

            response = requests.post(
                self.api_url,
                data=json.dumps({
                    "model": self.model_name,
                    "messages": [
      {"role": "user", "content": f"判断以下两个答案是否语义一致，一致输出'一致'，不一致输出'否'：\n答案1: {man}\n答案2: {model}"}
    ],
                    "temperature": 0.0
                }),
                headers=headers if headers else None,
                timeout=self.timeout
            )
            response.raise_for_status()
            data = response.json()
            result = data['choices'][0]['message']['content']
            # 检查是否明确表示正确
            is_match = (
                result == "correct" or
                result.startswith("correct") or
                "一致" in result or
                "相同" in result
            )
            reason = data.get("reason", "")
        except Exception as e:
            return CompareResult(
                is_match=False,
                method="llm_judge_error",
                reason=str(e)
            )

        return CompareResult(
            is_match=is_match,
            method="llm_judge",
            reason=reason
        )
