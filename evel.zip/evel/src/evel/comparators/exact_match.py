"""字符串完全匹配比较器"""
from dataclasses import dataclass
from typing import Optional


@dataclass
class CompareResult:
    """比较结果"""
    is_match: bool
    method: str
    score: Optional[float] = None
    reason: Optional[str] = None


class ExactMatchComparator:
    """字符串完全匹配比较器"""

    def compare(self, man: str, model: str) -> CompareResult:
        """
        比较标准答案和预测答案是否完全一致
        """
        if man == model:
            return CompareResult(is_match=True, method="exact_match")
        return CompareResult(is_match=False, method="exact_match")
