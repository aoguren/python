"""Cross-Encoder 评分比较器"""
from dataclasses import dataclass
from typing import Optional
import requests


@dataclass
class CompareResult:
    """比较结果"""
    is_match: bool
    method: str
    score: Optional[float] = None
    reason: Optional[str] = None


class CrossEncoderComparator:
    """Cross-Encoder 评分比较器"""

    def __init__(
        self,
        api_url: str,
        model_name: str,
        pass_threshold: float = 0.85,
        timeout: int = 30
    ):
        self.api_url = api_url
        self.model_name = model_name
        self.pass_threshold = pass_threshold
        self.timeout = timeout

    def compare(self, man: str, model: str) -> CompareResult:
        """
        比较两个答案的 Cross-Encoder 评分
        """
        try:
            response = requests.post(
                self.api_url,
                json={"text1": man, "text2": model, "model": self.model_name},
                timeout=self.timeout
            )
            response.raise_for_status()
            data = response.json()
            score = data["score"]
        except Exception:
            return CompareResult(is_match=False, method="cross_encoder_error", score=0.0)

        if score >= self.pass_threshold:
            return CompareResult(is_match=True, method="cross_encoder", score=score)
        else:
            return CompareResult(is_match=False, method="cross_encoder", score=score)
