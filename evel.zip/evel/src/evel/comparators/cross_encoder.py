"""Cross-Encoder 评分比较器"""
from dataclasses import dataclass
from typing import Optional
import requests


@dataclass
class CompareResult:
    """比较结果"""
    is_match: bool
    method: str
    score: Optional[float] = None
    reason: Optional[str] = None


class CrossEncoderComparator:
    """Cross-Encoder 评分比较器"""

    def __init__(
        self,
        api_url: str,
        model_name: str,
        api_key: str = "",
        pass_threshold: float = 0.85,
        timeout: int = 30
    ):
        self.api_url = api_url
        self.model_name = model_name
        self.api_key = api_key
        self.pass_threshold = pass_threshold
        self.timeout = timeout

    def compare(self, man: str, model: str) -> CompareResult:
        """
        比较两个答案的 Cross-Encoder 评分
        """
        try:
            headers = {}
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"

            response = requests.post(
                self.api_url,
                json={"query": man, "documents": [model], "model": self.model_name},
                headers=headers if headers else None,
                timeout=self.timeout
            )
            response.raise_for_status()
            data = response.json()
            score = data['results'][0]['relevance_score']
        except Exception:
            return CompareResult(is_match=False, method="cross_encoder_error", score=0.0)

        if score >= self.pass_threshold:
            return CompareResult(is_match=True, method="cross_encoder", score=score)
        else:
            return CompareResult(is_match=False, method="cross_encoder", score=score)
