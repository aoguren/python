"""字面相似度比较器（Levenshtein ratio）"""
from dataclasses import dataclass
from typing import Optional
import jellyfish


@dataclass
class CompareResult:
    """比较结果"""
    is_match: bool
    method: str
    score: Optional[float] = None
    reason: Optional[str] = None


class LiteralComparator:
    """字面相似度比较器（基于 Levenshtein ratio）"""

    def __init__(self, pass_threshold: float = 0.95, fail_threshold: float = 0.30):
        self.pass_threshold = pass_threshold
        self.fail_threshold = fail_threshold

    def compare(self, man: str, model: str) -> CompareResult:
        """
        比较两个答案的字面相似度
        - score >= pass_threshold: 判对
        - score <= fail_threshold: 判错
        - 灰区: 返回 is_match=False, method="literal_gray"
        """
        if not man or not model:
            score = 0.0
        else:
            distance = jellyfish.levenshtein_distance(man, model)
            max_len = max(len(man), len(model))
            score = 1.0 - (distance / max_len) if max_len > 0 else 0.0

        if score >= self.pass_threshold:
            return CompareResult(is_match=True, method="literal_match", score=score)
        elif score <= self.fail_threshold:
            return CompareResult(is_match=False, method="literal_fail", score=score)
        else:
            return CompareResult(is_match=False, method="literal_gray", score=score)
