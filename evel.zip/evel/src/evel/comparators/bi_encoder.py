"""Bi-Encoder 相似度比较器"""
from dataclasses import dataclass
from typing import Optional, List
import requests
import numpy as np


@dataclass
class CompareResult:
    """比较结果"""
    is_match: bool
    method: str
    score: Optional[float] = None
    reason: Optional[str] = None


class BiEncoderComparator:
    """Bi-Encoder 相似度比较器"""

    def __init__(
        self,
        api_url: str,
        model_name: str,
        api_key: str = "",
        pass_threshold: float = 0.95,
        fail_threshold: float = 0.30,
        timeout: int = 30
    ):
        self.api_url = api_url
        self.model_name = model_name
        self.api_key = api_key
        self.pass_threshold = pass_threshold
        self.fail_threshold = fail_threshold
        self.timeout = timeout

    def _get_embedding(self, text: str) -> List[float]:
        """调用远程 API 获取文本 embedding"""
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        response = requests.post(
            self.api_url,
            json={"input": text, "model": self.model_name},
            headers=headers if headers else None,
            timeout=self.timeout
        )
        response.raise_for_status()
        data = response.json()
        return data['data'][0]['embedding']

    @staticmethod
    def _cosine_similarity(a: List[float], b: List[float]) -> float:
        """计算余弦相似度"""
        a_np = np.array(a)
        b_np = np.array(b)
        dot_product = np.dot(a_np, b_np)
        norm_a = np.linalg.norm(a_np)
        norm_b = np.linalg.norm(b_np)
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return float(dot_product / (norm_a * norm_b))

    def compare(self, man: str, model: str) -> CompareResult:
        """
        比较两个答案的 Bi-Encoder 相似度
        """
        try:
            man_embedding = self._get_embedding(man)
            model_embedding = self._get_embedding(model)
            score = self._cosine_similarity(man_embedding, model_embedding)
        except Exception:
            return CompareResult(is_match=False, method="bi_encoder_error", score=0.0)

        if score >= self.pass_threshold:
            return CompareResult(is_match=True, method="bi_encoder", score=score)
        elif score <= self.fail_threshold:
            return CompareResult(is_match=False, method="bi_encoder_fail", score=score)
        else:
            return CompareResult(is_match=False, method="bi_encoder_gray", score=score)
