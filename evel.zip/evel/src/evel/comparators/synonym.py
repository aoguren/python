"""同义词匹配比较器"""
from dataclasses import dataclass
from typing import Optional, Set, List


@dataclass
class CompareResult:
    """比较结果"""
    is_match: bool
    method: str
    score: Optional[float] = None
    reason: Optional[str] = None


class SynonymComparator:
    """同义词词典匹配比较器"""

    def __init__(self, dict_path: str):
        self.synonym_sets: List[Set[str]] = []
        self._load_dict(dict_path)

    def _load_dict(self, dict_path: str):
        """加载同义词词典，每行一个同义词集合，词之间用空格分隔"""
        with open(dict_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    words = set(line.split())
                    if words:
                        self.synonym_sets.append(words)

    def _find_synonym_set(self, word: str) -> Optional[Set[str]]:
        """查找词所在的同义词集合"""
        for syn_set in self.synonym_sets:
            if word in syn_set:
                return syn_set
        return None

    def compare(self, man: str, model: str) -> CompareResult:
        """
        比较两个答案是否在同一个同义词集合中
        """
        man_set = self._find_synonym_set(man)
        if man_set is None:
            return CompareResult(is_match=False, method="synonym")

        if model in man_set:
            return CompareResult(is_match=True, method="synonym")

        return CompareResult(is_match=False, method="synonym")
