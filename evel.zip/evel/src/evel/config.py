"""配置加载模块"""
import toml
from pathlib import Path
from dataclasses import dataclass
from typing import List, Dict, Any


@dataclass
class Config:
    """配置类"""
    thresholds: Dict[str, Any]
    models: Dict[str, Any]
    llm: Dict[str, Any]
    synonym: Dict[str, str]
    fields: List[str]
    llm_fallback_enabled: bool
    config_dir: Path  # 配置文件所在目录，用于解析相对路径

    def __init__(self, config_path: str):
        config_path = Path(config_path)
        self.config_dir = config_path.parent.resolve()

        with open(config_path, 'r', encoding='utf-8') as f:
            data = toml.load(f)

        self.thresholds = dict(data.get("thresholds", {}))
        self.models = dict(data.get("models", {}))
        self.llm = dict(data.get("llm", {}))
        self.synonym = dict(data.get("synonym", {}))
        self.fields = list(data.get("fields", {}).get("evaluate", []))
        self.llm_fallback_enabled = self.thresholds.get("llm_fallback_enabled", False)