"""主评测引擎"""
from dataclasses import dataclass
from typing import Optional
from .comparators.exact_match import ExactMatchComparator
from .comparators.synonym import SynonymComparator
from .comparators.literal import LiteralComparator
from .comparators.bi_encoder import BiEncoderComparator
from .comparators.cross_encoder import CrossEncoderComparator
from .comparators.llm_judge import LLMJudgeComparator


@dataclass
class CompareResult:
    """比较结果"""
    is_match: bool
    method: str
    score: Optional[float] = None
    reason: Optional[str] = None


class Evaluator:
    """主评测引擎"""

    def __init__(self, config):
        self.config = config
        self.thresholds = config.thresholds
        self.models = config.models
        self.llm_config = config.llm

        # 初始化比较器
        self.exact_match = ExactMatchComparator()
        self.synonym = SynonymComparator(config.synonym["dict_path"])
        self.literal = LiteralComparator(
            pass_threshold=self.thresholds["literal_pass"],
            fail_threshold=self.thresholds["literal_fail"]
        )
        self.bi_encoder = BiEncoderComparator(
            api_url=self.models["bi_encoder_api_url"],
            model_name=self.models["bi_encoder_model"],
            pass_threshold=self.thresholds["bi_encoder_pass"],
            fail_threshold=self.thresholds["bi_encoder_fail"]
        )
        self.cross_encoder = CrossEncoderComparator(
            api_url=self.models["cross_encoder_api_url"],
            model_name=self.models["cross_encoder_model"],
            pass_threshold=self.thresholds["cross_encoder_pass"]
        )
        if config.llm_fallback_enabled and self.llm_config:
            self.llm_judge = LLMJudgeComparator(
                api_url=self.llm_config["api_url"],
                model_name=self.llm_config["model_name"],
                timeout=self.llm_config.get("timeout", 30)
            )
        else:
            self.llm_judge = None

    @staticmethod
    def count_chars(text: str) -> int:
        """计算字数（中文按字符数，英文按单词数）"""
        import re
        chinese_chars = len(re.findall(r'[一-鿿]', text))
        english_words = len(re.findall(r'[a-zA-Z]+', text))
        return chinese_chars + english_words

    def _is_english_words(self, text: str) -> bool:
        """判断是否为英文单词文本"""
        import re
        chinese_chars = len(re.findall(r'[一-鿿]', text))
        return chinese_chars == 0 and len(re.findall(r'[a-zA-Z]+', text)) > 0

    def evaluate_single(self, man: str, model: str) -> CompareResult:
        """
        对单对答案进行评测
        """
        # Step 1: 完全一致检查
        result = self.exact_match.compare(man, model)
        if result.is_match:
            return result

        # Step 2: 同义词检查
        result = self.synonym.compare(man, model)
        if result.is_match:
            return result

        # Step 3: 字数判断
        char_count = self.count_chars(man) if not self._is_english_words(man) else self.count_chars(man)

        if char_count < 3:
            return self._evaluate_short(man, model)
        else:
            return self._evaluate_long(man, model)

    def _evaluate_short(self, man: str, model: str) -> CompareResult:
        """评测短文本（< 3字或单词数 < 3）"""
        # 字面相似度
        result = self.literal.compare(man, model)
        if result.is_match:
            return result
        if result.method == "literal_fail":
            return result

        # 灰区: Cross-Encoder
        return self.cross_encoder.compare(man, model)

    def _evaluate_long(self, man: str, model: str) -> CompareResult:
        """评测长文本（>= 3字或单词数 >= 3）"""
        # Bi-Encoder 相似度
        result = self.bi_encoder.compare(man, model)
        if result.is_match or result.method == "bi_encoder_fail":
            return result

        # 灰区: Cross-Encoder
        result = self.cross_encoder.compare(man, model)
        if result.is_match:
            return result

        # LLM 兜底
        if self.llm_judge:
            return self.llm_judge.compare(man, model)

        return result
