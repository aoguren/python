"""evel - 自动评测工具 主入口"""
import sys
from typing import Dict, Any
from openpyxl import load_workbook
from .config import Config
from .evaluator import Evaluator
from .output import OutputGenerator


def evaluate(input_path: str, config_path: str, output_path: str) -> Dict[str, Any]:
    """
    主评测函数

    Args:
        input_path: 输入 Excel 路径
        config_path: TOML 配置文件路径
        output_path: 输出 Excel 路径

    Returns:
        {
            "total_accuracy": float,
            "sheet1_path": str,
            "details": Dict
        }
    """
    # 加载配置
    config = Config(config_path)

    # 加载输入 Excel
    wb = load_workbook(input_path)
    ws = wb.active

    # 提取表头和数据
    headers = [cell.value for cell in ws[1]]
    rows = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if any(cell is not None for cell in row):
            rows.append(dict(zip(headers, row)))

    # 初始化评测引擎
    evaluator = Evaluator(config)

    # 对每个字段进行评测
    results = {}
    for field in config.fields:
        man_key = f"{field}_man"
        model_key = f"{field}_model"

        field_results = []
        for row in rows:
            man = str(row.get(man_key, ""))
            model = str(row.get(model_key, ""))
            result = evaluator.evaluate_single(man, model)
            field_results.append({
                "is_match": result.is_match,
                "method": result.method,
                "score": result.score,
                "reason": result.reason
            })
        results[field] = field_results

    # 生成输出
    generator = OutputGenerator(rows, results)
    total_accuracy, details = generator.generate(output_path)

    return {
        "total_accuracy": total_accuracy,
        "sheet1_path": output_path,
        "details": details
    }


def main():
    if len(sys.argv) != 4:
        print("用法: python -m evel <input.xlsx> <config.toml> <output.xlsx>")
        sys.exit(1)

    input_path = sys.argv[1]
    config_path = sys.argv[2]
    output_path = sys.argv[3]

    result = evaluate(input_path, config_path, output_path)
    print(f"评测完成！总体正确率: {result['total_accuracy']:.1%}")
    print(f"输出文件: {result['sheet1_path']}")


if __name__ == "__main__":
    main()
