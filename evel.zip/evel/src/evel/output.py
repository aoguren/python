"""Excel 输出生成模块"""
from typing import Dict, List, Any, Tuple
from openpyxl import Workbook


class OutputGenerator:
    """Excel 输出生成器"""

    def __init__(self, input_data: List[Dict], results: Dict[str, List[Dict]]):
        self.input_data = input_data
        self.results = results

    def generate(self, output_path: str) -> Tuple[float, Dict[str, Dict]]:
        """
        生成输出 Excel 文件
        返回: (总体正确率, 各字段统计详情)
        """
        wb = Workbook()

        # Sheet 1: 原始数据扩展
        ws1 = wb.active
        ws1.title = "Sheet1"

        # 构建表头
        headers = list(self.input_data[0].keys()) if self.input_data else []
        for field in self.results.keys():
            headers.append(f"{field}_result")
            headers.append(f"{field}_method")

        ws1.append(headers)

        # 填充数据
        for idx, row in enumerate(self.input_data):
            row_data = list(row.values())
            for field, field_results in self.results.items():
                if idx < len(field_results):
                    r = field_results[idx]
                    row_data.append("✅" if r["is_match"] else "❌")
                    row_data.append(r["method"])
                else:
                    row_data.append("")
                    row_data.append("")
            ws1.append(row_data)

        # Sheet 2: 统计汇总
        ws2 = wb.create_sheet("统计汇总")
        ws2.append(["字段名", "正确数", "总数", "正确率"])

        details = {}
        total_correct = 0
        total_count = 0

        for field, field_results in self.results.items():
            correct = sum(1 for r in field_results if r["is_match"])
            total = len(field_results)
            accuracy = correct / total if total > 0 else 0.0
            total_correct += correct
            total_count += total
            details[field] = {"correct": correct, "total": total, "accuracy": accuracy}
            ws2.append([field, correct, total, f"{accuracy:.1%}"])

        overall_accuracy = total_correct / total_count if total_count > 0 else 0.0
        ws2.append(["总体", total_correct, total_count, f"{overall_accuracy:.1%}"])

        wb.save(output_path)

        return overall_accuracy, details
