"""evel - 自动评测工具"""
__version__ = "0.1.0"

from .config import Config
from .evaluator import Evaluator
from .output import OutputGenerator


def evaluate(input_path: str, config_path: str, output_path: str):
    """
    主评测函数

    Args:
        input_path: 输入 Excel 路径
        config_path: TOML 配置文件路径
        output_path: 输出 Excel 路径

    Returns:
        {
            "total_accuracy": float,
            "sheet1_path": str,
            "details": Dict
        }
    """
    from .__main__ import evaluate as _evaluate
    return _evaluate(input_path, config_path, output_path)


__all__ = ["evaluate", "Evaluator", "OutputGenerator", "Config"]