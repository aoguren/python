# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 项目概述

这是一个自动评测工具，用于判断模型预测答案的正确性。项目设计文档见 [DESIGN.md](DESIGN.md)。

## 技术栈

- **语言**: Python

## 项目状态

项目尚未实现。当前仅包含设计文档。

## 常用命令（待填充）

实现后添加以下内容：
- 构建命令
- 测试命令
- Lint 命令
- 如何运行单个测试

## 架构说明（待填充）

实现后添加以下内容：
- 代码目录结构
- 核心模块说明
- 关键类/函数说明
