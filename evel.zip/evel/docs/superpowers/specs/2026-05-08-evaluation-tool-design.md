# 自动评测工具设计文档

## 1. 项目概述

**项目名称**: evel（Evaluation Tool）

**项目目的**: 自动评测工具，用于判断模型预测答案的正确性。给定人工标准答案和模型预测答案，采用分层评分策略输出评测结果。

**技术栈**: Python

---

## 2. 项目结构

```
evel/
├── src/
│   └── evel/
│       ├── __init__.py
│       ├── evaluator.py          # 主评测引擎
│       ├── comparators/
│       │   ├── __init__.py
│       │   ├── exact_match.py    # 字符串完全匹配
│       │   ├── synonym.py        # 同义词匹配
│       │   ├── literal.py        # 字面相似度（Levenshtein ratio）
│       │   ├── bi_encoder.py     # Bi-Encoder 相似度
│       │   ├── cross_encoder.py  # Cross-Encoder 评分
│       │   └── llm_judge.py      # LLM 兜底判定
│       ├── config.py             # TOML 配置加载
│       └── output.py             # Excel 输出生成
├── synonym/
│   └── synonym.txt                # 同义词词典（每行一个同义词集合）
├── tests/
├── pyproject.toml
├── config.toml                   # 主配置文件
└── docs/
    └── superpowers/
        └── specs/
            └── 2026-05-08-evaluation-tool-design.md
```

---

## 3. 配置结构 (config.toml)

```toml
[thresholds]
# 字面相似度阈值（关键词 < 3字）
literal_pass = 0.95    # Levenshtein ratio ≥ 此值 → 判对
literal_fail = 0.30    # Levenshtein ratio ≤ 此值 → 判错

# Cross-Encoder 阈值
cross_encoder_pass = 0.85

# Bi-Encoder 阈值（句子 ≥ 3字）
bi_encoder_pass = 0.95
bi_encoder_fail = 0.30

# LLM 兜底开关
llm_fallback_enabled = true

[models]
bi_encoder_model = "Qwen3-Embedding-4B"
bi_encoder_api_url = "http://api.example.com/embedding"
cross_encoder_model = "Qwen3-Reranker-4B"
cross_encoder_api_url = "http://api.example.com/reranker"

[llm]
api_url = "http://api.example.com/llm"
model_name = "team-llm"
timeout = 30

[synonym]
dict_path = "synonym/synonym.txt"

[fields]
evaluate = ["要素", "条款"]  # 要评测的字段列表
```

---

## 4. 同义词词典格式

`synonym/synonym.txt` 每行一个同义词集合，词之间用空格分隔：

```
苹果 手机 移动电话
电脑 计算机 PC
```

---

## 5. 评测流程

```
输入: 标准答案 (man) + 预测答案 (model)

Step 1: 完全一致检查
    └─ 字符串完全匹配？ → 判对 ✅，方法: "exact_match"

Step 2: 同义词词典检查
    └─ 两者都在同一同义词集合？ → 判对 ✅，方法: "synonym"

Step 3: 字数判断
    ├─ 关键词（< 3字 或 单词数 < 3）
    │   ├─ 字面相似度（Levenshtein ratio）
    │   │   ├─ ≥ literal_pass → 判对 ✅，方法: "literal_match"
    │   │   ├─ ≤ literal_fail → 判错 ❌，方法: "literal_fail"
    │   │   └─ 灰区(literal_fail ~ literal_pass) → Cross-Encoder
    │   └─ Cross-Encoder
    │       ├─ ≥ cross_encoder_pass → 判对 ✅，方法: "cross_encoder"
    │       └─ < cross_encoder_pass → LLM 兜底 或 判错
    │
    └─ 句子（≥ 3字 或 单词数 ≥ 3）
        ├─ Bi-Encoder 相似度
        │   ├─ ≥ bi_encoder_pass → 判对 ✅，方法: "bi_encoder"
        │   ├─ ≤ bi_encoder_fail → 判错 ❌，方法: "bi_encoder_fail"
        │   └─ 灰区 → Cross-Encoder
        ├─ Cross-Encoder
        │   ├─ ≥ cross_encoder_pass → 判对 ✅，方法: "cross_encoder"
        │   └─ < cross_encoder_pass → LLM 兜底
        └─ LLM 兜底
            └─ 判定 + 理由（可选）
```

---

## 6. 输入输出格式

### 输入

Excel 文件，包含多列数据，字段名配置后自动拼接 `_man` 和 `_model` 后缀获取答案对。

例如配置 `evaluate = ["要素", "条款"]`，则实际读取字段为：
- `要素_man`, `要素_model`
- `条款_man`, `条款_model`

### 输出

**Sheet 1 - 原始数据扩展**：在原始 Excel 基础上，每个评测字段添加 2 列

| 文件名 | ... | 要素_result | 要素_method | 条款_result | 条款_method |
|--------|-----|-------------|-------------|-------------|-------------|
| doc1   | ... | ✅          | exact_match | ❌          | literal_fail |

**Sheet 2 - 统计汇总**：

| 字段名 | 正确数 | 总数 | 正确率 |
|--------|--------|------|--------|
| 要素   | 45     | 50   | 90.0%  |
| 条款   | 48     | 50   | 96.0%  |
| **总体** | **93** | **100** | **93.0%** |

### 接口返回值

```python
{
    "total_accuracy": 0.93,           # 总体正确率（float），供下游使用
    "sheet1_path": "output.xlsx",     # 输出Excel路径
    "details": {
        "要素": {"correct": 45, "total": 50, "accuracy": 0.90},
        "条款": {"correct": 48, "total": 50, "accuracy": 0.96},
    }
}
```

---

## 7. 核心模块说明

| 模块 | 职责 |
|------|------|
| `evaluator.py` | 主引擎，按流程编排调度各比较器 |
| `comparators/exact_match.py` | 字符串完全匹配 |
| `comparators/synonym.py` | 同义词词典匹配 |
| `comparators/literal.py` | Levenshtein ratio 字面相似度 |
| `comparators/bi_encoder.py` | Bi-Encoder 相似度（调用远程 API） |
| `comparators/cross_encoder.py` | Cross-Encoder 评分（调用远程 API） |
| `comparators/llm_judge.py` | LLM 兜底判定（调用远程 API） |
| `config.py` | 加载 TOML 配置 |
| `output.py` | 生成双 Sheet Excel 输出 |
