# 自动评测工具实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 实现自动评测工具，读取含人工答案和模型预测答案的 Excel，输出评测结果（双 Sheet Excel + 总体正确率）

**Architecture:** 分层评分架构，主引擎编排各比较器（字符串匹配 → 同义词 → 字面相似度 → Bi-Encoder → Cross-Encoder → LLM 兜底），所有阈值通过 TOML 配置

**Tech Stack:** Python, toml, openpyxl, jellyfish (Levenshtein), requests (API 调用)

---

## 文件结构

```
evel/
├── src/
│   └── evel/
│       ├── __init__.py
│       ├── evaluator.py          # 主评测引擎
│       ├── comparators/
│       │   ├── __init__.py
│       │   ├── exact_match.py    # 字符串完全匹配
│       │   ├── synonym.py        # 同义词匹配
│       │   ├── literal.py        # 字面相似度（Levenshtein ratio）
│       │   ├── bi_encoder.py     # Bi-Encoder 相似度
│       │   ├── cross_encoder.py  # Cross-Encoder 评分
│       │   └── llm_judge.py      # LLM 兜底判定
│       ├── config.py             # TOML 配置加载
│       └── output.py             # Excel 输出生成
├── synonym/
│   └── synonym.txt                # 同义词词典
├── tests/
│   └── evel/
│       ├── __init__.py
│       ├── test_config.py
│       ├── test_exact_match.py
│       ├── test_synonym.py
│       ├── test_literal.py
│       ├── test_evaluator.py
│       └── test_output.py
├── pyproject.toml
├── config.toml
└── docs/
    └── superpowers/
        ├── specs/
        │   └── 2026-05-08-evaluation-tool-design.md
        └── plans/
            └── 2026-05-08-evaluation-tool-implementation-plan.md
```

---

### Task 1: 项目初始化

**Files:**
- Create: `pyproject.toml`
- Create: `config.toml`
- Create: `src/evel/__init__.py`
- Create: `src/evel/comparators/__init__.py`
- Create: `synonym/synonym.txt`（示例词典）

- [ ] **Step 1: 创建 pyproject.toml**

```toml
[project]
name = "evel"
version = "0.1.0"
description = "自动评测工具"
requires-python = ">=3.10"
dependencies = [
    "toml>=0.10.2",
    "openpyxl>=3.1.0",
    "jellyfish>=1.0.0",
    "requests>=2.31.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0.0",
    "pytest-asyncio>=0.23.0",
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.pytest.ini_options]
testpaths = ["tests"]
pythonpath = ["src"]
```

- [ ] **Step 2: 创建 config.toml**

```toml
[thresholds]
literal_pass = 0.95
literal_fail = 0.30
cross_encoder_pass = 0.85
bi_encoder_pass = 0.95
bi_encoder_fail = 0.30
llm_fallback_enabled = true

[models]
bi_encoder_model = "Qwen3-Embedding-4B"
bi_encoder_api_url = "http://api.example.com/embedding"
cross_encoder_model = "Qwen3-Reranker-4B"
cross_encoder_api_url = "http://api.example.com/reranker"

[llm]
api_url = "http://api.example.com/llm"
model_name = "team-llm"
timeout = 30

[synonym]
dict_path = "synonym/synonym.txt"

[fields]
evaluate = ["要素", "条款"]
```

- [ ] **Step 3: 创建空 `src/evel/__init__.py`**

```python
"""evel - 自动评测工具"""
__version__ = "0.1.0"
```

- [ ] **Step 4: 创建 `src/evel/comparators/__init__.py`**

```python
"""比较器模块"""
from .exact_match import ExactMatchComparator
from .synonym import SynonymComparator
from .literal import LiteralComparator
from .bi_encoder import BiEncoderComparator
from .cross_encoder import CrossEncoderComparator
from .llm_judge import LLMJudgeComparator

__all__ = [
    "ExactMatchComparator",
    "SynonymComparator",
    "LiteralComparator",
    "BiEncoderComparator",
    "CrossEncoderComparator",
    "LLMJudgeComparator",
]
```

- [ ] **Step 5: 创建示例同义词词典 `synonym/synonym.txt`**

```
苹果 手机 移动电话
电脑 计算机 PC
```

- [ ] **Step 6: 提交**

```bash
git add pyproject.toml config.toml src/evel/__init__.py src/evel/comparators/__init__.py synonym/synonym.txt
git commit -m "feat: 项目初始化 - 基础结构和配置"
```

---

### Task 2: 配置加载模块

**Files:**
- Create: `src/evel/config.py`
- Create: `tests/evel/__init__.py`
- Create: `tests/evel/test_config.py`

- [ ] **Step 1: 创建测试 `tests/evel/test_config.py`**

```python
import tempfile
import os
from evel.config import Config

def test_config_load():
    config_content = """
[thresholds]
literal_pass = 0.95
literal_fail = 0.30
cross_encoder_pass = 0.85
bi_encoder_pass = 0.95
bi_encoder_fail = 0.30
llm_fallback_enabled = true

[models]
bi_encoder_model = "Qwen3-Embedding-4B"
bi_encoder_api_url = "http://api.example.com/embedding"
cross_encoder_model = "Qwen3-Reranker-4B"
cross_encoder_api_url = "http://api.example.com/reranker"

[llm]
api_url = "http://api.example.com/llm"
model_name = "team-llm"
timeout = 30

[synonym]
dict_path = "synonym/synonym.txt"

[fields]
evaluate = ["要素", "条款"]
"""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.toml', delete=False) as f:
        f.write(config_content)
        config_path = f.name

    try:
        config = Config(config_path)
        assert config.thresholds["literal_pass"] == 0.95
        assert config.thresholds["literal_fail"] == 0.30
        assert config.models["bi_encoder_api_url"] == "http://api.example.com/embedding"
        assert config.fields == ["要素", "条款"]
        assert config.llm_fallback_enabled is True
    finally:
        os.unlink(config_path)
```

- [ ] **Step 2: 运行测试验证失败**

Run: `pytest tests/evel/test_config.py::test_config_load -v`
Expected: FAIL - ModuleNotFoundError: No module named 'evel'

- [ ] **Step 3: 实现 `src/evel/config.py`**

```python
"""配置加载模块"""
import toml
from dataclasses import dataclass
from typing import List, Dict, Any


@dataclass
class Config:
    """配置类"""
    thresholds: Dict[str, Any]
    models: Dict[str, str]
    llm: Dict[str, Any]
    synonym: Dict[str, str]
    fields: List[str]
    llm_fallback_enabled: bool

    def __init__(self, config_path: str):
        with open(config_path, 'r', encoding='utf-8') as f:
            data = toml.load(f)

        self.thresholds = dict(data.get("thresholds", {}))
        self.models = dict(data.get("models", {}))
        self.llm = dict(data.get("llm", {}))
        self.synonym = dict(data.get("synonym", {}))
        self.fields = list(data.get("fields", {}).get("evaluate", []))
        self.llm_fallback_enabled = self.thresholds.get("llm_fallback_enabled", False)
```

- [ ] **Step 4: 运行测试验证通过**

Run: `pytest tests/evel/test_config.py::test_config_load -v`
Expected: PASS

- [ ] **Step 5: 提交**

```bash
git add src/evel/config.py tests/evel/test_config.py tests/evel/__init__.py
git commit -m "feat: 添加配置加载模块"
```

---

### Task 3: 字符串完全匹配比较器

**Files:**
- Create: `src/evel/comparators/exact_match.py`
- Create: `tests/evel/test_exact_match.py`

- [ ] **Step 1: 创建测试 `tests/evel/test_exact_match.py`**

```python
from evel.comparators.exact_match import ExactMatchComparator

def test_exact_match_positive():
    comparator = ExactMatchComparator()
    result = comparator.compare("苹果", "苹果")
    assert result.is_match is True
    assert result.method == "exact_match"

def test_exact_match_negative():
    comparator = ExactMatchComparator()
    result = comparator.compare("苹果", "香蕉")
    assert result.is_match is False
    assert result.method == "exact_match"

def test_exact_match_with_whitespace():
    comparator = ExactMatchComparator()
    result = comparator.compare("苹果 ", "苹果")
    # 完全一致才判对，考虑是否需要 strip
    # 根据设计，严格字符串匹配
    result_stripped = comparator.compare("苹果", "苹果 ")
    assert result_stripped.is_match is True
```

- [ ] **Step 2: 运行测试验证失败**

Run: `pytest tests/evel/test_exact_match.py -v`
Expected: FAIL - ModuleNotFoundError

- [ ] **Step 3: 实现 `src/evel/comparators/exact_match.py`**

```python
"""字符串完全匹配比较器"""
from dataclasses import dataclass
from typing import Optional


@dataclass
class CompareResult:
    """比较结果"""
    is_match: bool
    method: str
    score: Optional[float] = None
    reason: Optional[str] = None


class ExactMatchComparator:
    """字符串完全匹配比较器"""

    def compare(self, man: str, model: str) -> CompareResult:
        """
        比较标准答案和预测答案是否完全一致
        """
        if man == model:
            return CompareResult(is_match=True, method="exact_match")
        return CompareResult(is_match=False, method="exact_match")
```

- [ ] **Step 4: 运行测试验证通过**

Run: `pytest tests/evel/test_exact_match.py -v`
Expected: PASS

- [ ] **Step 5: 提交**

```bash
git add src/evel/comparators/exact_match.py tests/evel/test_exact_match.py
git commit -m "feat: 添加字符串完全匹配比较器"
```

---

### Task 4: 同义词匹配比较器

**Files:**
- Create: `src/evel/comparators/synonym.py`
- Create: `tests/evel/test_synonym.py`
- Create: `tests/evel/synonym_test.txt`（测试用词典）

- [ ] **Step 1: 创建测试 `tests/evel/test_synonym.py`**

```python
import tempfile
import os
from evel.comparators.synonym import SynonymComparator

def test_synonym_match():
    # 创建测试词典
    dict_content = "苹果 手机 移动电话\n电脑 计算机 PC"
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        f.write(dict_content)
        dict_path = f.name

    try:
        comparator = SynonymComparator(dict_path)
        result = comparator.compare("苹果", "手机")
        assert result.is_match is True
        assert result.method == "synonym"
    finally:
        os.unlink(dict_path)

def test_synonym_no_match():
    dict_content = "苹果 手机\n电脑 计算机"
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        f.write(dict_content)
        dict_path = f.name

    try:
        comparator = SynonymComparator(dict_path)
        result = comparator.compare("苹果", "电脑")
        assert result.is_match is False
        assert result.method == "synonym"
    finally:
        os.unlink(dict_path)

def test_synonym_not_in_dict():
    dict_content = "苹果 手机"
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        f.write(dict_content)
        dict_path = f.name

    try:
        comparator = SynonymComparator(dict_path)
        result = comparator.compare("香蕉", "苹果")
        assert result.is_match is False
    finally:
        os.unlink(dict_path)
```

- [ ] **Step 2: 运行测试验证失败**

Run: `pytest tests/evel/test_synonym.py -v`
Expected: FAIL

- [ ] **Step 3: 实现 `src/evel/comparators/synonym.py`**

```python
"""同义词匹配比较器"""
from dataclasses import dataclass
from typing import Optional, Set, List


@dataclass
class CompareResult:
    """比较结果"""
    is_match: bool
    method: str
    score: Optional[float] = None
    reason: Optional[str] = None


class SynonymComparator:
    """同义词词典匹配比较器"""

    def __init__(self, dict_path: str):
        self.synonym_sets: List[Set[str]] = []
        self._load_dict(dict_path)

    def _load_dict(self, dict_path: str):
        """加载同义词词典，每行一个同义词集合，词之间用空格分隔"""
        with open(dict_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    words = set(line.split())
                    if words:
                        self.synonym_sets.append(words)

    def _find_synonym_set(self, word: str) -> Optional[Set[str]]:
        """查找词所在的同义词集合"""
        for syn_set in self.synonym_sets:
            if word in syn_set:
                return syn_set
        return None

    def compare(self, man: str, model: str) -> CompareResult:
        """
        比较两个答案是否在同一个同义词集合中
        """
        man_set = self._find_synonym_set(man)
        if man_set is None:
            return CompareResult(is_match=False, method="synonym")

        if model in man_set:
            return CompareResult(is_match=True, method="synonym")

        return CompareResult(is_match=False, method="synonym")
```

- [ ] **Step 4: 运行测试验证通过**

Run: `pytest tests/evel/test_synonym.py -v`
Expected: PASS

- [ ] **Step 5: 提交**

```bash
git add src/evel/comparators/synonym.py tests/evel/test_synonym.py
git commit -m "feat: 添加同义词匹配比较器"
```

---

### Task 5: 字面相似度比较器（Levenshtein ratio）

**Files:**
- Create: `src/evel/comparators/literal.py`
- Create: `tests/evel/test_literal.py`

- [ ] **Step 1: 创建测试 `tests/evel/test_literal.py`**

```python
from evel.comparators.literal import LiteralComparator

def test_literal_match_high_similarity():
    comparator = LiteralComparator(pass_threshold=0.95, fail_threshold=0.30)
    result = comparator.compare("苹果", "苹果")
    assert result.is_match is True
    assert result.score == 1.0
    assert result.method == "literal_match"

def test_literal_fail_low_similarity():
    comparator = LiteralComparator(pass_threshold=0.95, fail_threshold=0.30)
    result = comparator.compare("苹果", "香蕉")
    assert result.is_match is False
    assert result.score < 0.30
    assert result.method == "literal_fail"

def test_literal_gray_zone():
    comparator = LiteralComparator(pass_threshold=0.95, fail_threshold=0.30)
    result = comparator.compare("苹果", "苹雇")
    # 编辑距离 0.5 在灰区
    assert 0.30 < result.score < 0.95
    assert result.is_match is False
    assert result.method == "literal_gray"
```

- [ ] **Step 2: 运行测试验证失败**

Run: `pytest tests/evel/test_literal.py -v`
Expected: FAIL

- [ ] **Step 3: 实现 `src/evel/comparators/literal.py`**

```python
"""字面相似度比较器（Levenshtein ratio）"""
from dataclasses import dataclass
from typing import Optional
import jellyfish


@dataclass
class CompareResult:
    """比较结果"""
    is_match: bool
    method: str
    score: Optional[float] = None
    reason: Optional[str] = None


class LiteralComparator:
    """字面相似度比较器（基于 Levenshtein ratio）"""

    def __init__(self, pass_threshold: float = 0.95, fail_threshold: float = 0.30):
        self.pass_threshold = pass_threshold
        self.fail_threshold = fail_threshold

    def compare(self, man: str, model: str) -> CompareResult:
        """
        比较两个答案的字面相似度
        - score >= pass_threshold: 判对
        - score <= fail_threshold: 判错
        - 灰区: 返回 is_match=False, method="literal_gray"
        """
        if not man or not model:
            score = 0.0
        else:
            score = jellyfish.levenshtein_ratio(man, model)

        if score >= self.pass_threshold:
            return CompareResult(is_match=True, method="literal_match", score=score)
        elif score <= self.fail_threshold:
            return CompareResult(is_match=False, method="literal_fail", score=score)
        else:
            return CompareResult(is_match=False, method="literal_gray", score=score)
```

- [ ] **Step 4: 运行测试验证通过**

Run: `pytest tests/evel/test_literal.py -v`
Expected: PASS

- [ ] **Step 5: 提交**

```bash
git add src/evel/comparators/literal.py tests/evel/test_literal.py
git commit -m "feat: 添加字面相似度比较器 (Levenshtein ratio)"
```

---

### Task 6: Bi-Encoder 比较器

**Files:**
- Create: `src/evel/comparators/bi_encoder.py`
- Create: `tests/evel/test_bi_encoder.py`（需要 mock）

- [ ] **Step 1: 创建测试 `tests/evel/test_bi_encoder.py`**

```python
import pytest
from unittest.mock import patch, MagicMock
from evel.comparators.bi_encoder import BiEncoderComparator

def test_bi_encoder_high_similarity():
    comparator = BiEncoderComparator(
        api_url="http://api.example.com/embedding",
        model_name="Qwen3-Embedding-4B",
        pass_threshold=0.95,
        fail_threshold=0.30
    )

    mock_response = MagicMock()
    mock_response.json.return_value = {"embedding": [0.1, 0.9]}

    with patch('requests.post', return_value=mock_response) as mock_post:
        # 需要 mock 两个 embedding 相同
        mock_post.return_value.json.return_value = {"embedding": [0.5, 0.5]}

        result = comparator.compare("苹果", "苹果")

    # 实际测试需要更复杂的 mock 来模拟余弦相似度
    # 这里简化处理
    assert result.method == "bi_encoder"
    assert isinstance(result.score, float)

def test_bi_encoder_gray_zone():
    comparator = BiEncoderComparator(
        api_url="http://api.example.com/embedding",
        model_name="Qwen3-Embedding-4B",
        pass_threshold=0.95,
        fail_threshold=0.30
    )
    # 灰区测试
    result = comparator._cosine_similarity([0.5, 0.5], [0.6, 0.4])
    assert 0.30 < result < 0.95
```

- [ ] **Step 2: 运行测试验证失败**

Run: `pytest tests/evel/test_bi_encoder.py -v`
Expected: FAIL

- [ ] **Step 3: 实现 `src/evel/comparators/bi_encoder.py`**

```python
"""Bi-Encoder 相似度比较器"""
from dataclasses import dataclass
from typing import Optional, List
import requests
import numpy as np


@dataclass
class CompareResult:
    """比较结果"""
    is_match: bool
    method: str
    score: Optional[float] = None
    reason: Optional[str] = None


class BiEncoderComparator:
    """Bi-Encoder 相似度比较器"""

    def __init__(
        self,
        api_url: str,
        model_name: str,
        pass_threshold: float = 0.95,
        fail_threshold: float = 0.30,
        timeout: int = 30
    ):
        self.api_url = api_url
        self.model_name = model_name
        self.pass_threshold = pass_threshold
        self.fail_threshold = fail_threshold
        self.timeout = timeout

    def _get_embedding(self, text: str) -> List[float]:
        """调用远程 API 获取文本 embedding"""
        response = requests.post(
            self.api_url,
            json={"text": text, "model": self.model_name},
            timeout=self.timeout
        )
        response.raise_for_status()
        data = response.json()
        return data["embedding"]

    @staticmethod
    def _cosine_similarity(a: List[float], b: List[float]) -> float:
        """计算余弦相似度"""
        a_np = np.array(a)
        b_np = np.array(b)
        dot_product = np.dot(a_np, b_np)
        norm_a = np.linalg.norm(a_np)
        norm_b = np.linalg.norm(b_np)
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return float(dot_product / (norm_a * norm_b))

    def compare(self, man: str, model: str) -> CompareResult:
        """
        比较两个答案的 Bi-Encoder 相似度
        """
        try:
            man_embedding = self._get_embedding(man)
            model_embedding = self._get_embedding(model)
            score = self._cosine_similarity(man_embedding, model_embedding)
        except Exception:
            return CompareResult(is_match=False, method="bi_encoder_error", score=0.0)

        if score >= self.pass_threshold:
            return CompareResult(is_match=True, method="bi_encoder", score=score)
        elif score <= self.fail_threshold:
            return CompareResult(is_match=False, method="bi_encoder_fail", score=score)
        else:
            return CompareResult(is_match=False, method="bi_encoder_gray", score=score)
```

- [ ] **Step 4: 运行测试验证通过**

Run: `pytest tests/evel/test_bi_encoder.py -v`
Expected: PASS

- [ ] **Step 5: 提交**

```bash
git add src/evel/comparators/bi_encoder.py tests/evel/test_bi_encoder.py
git commit -m "feat: 添加 Bi-Encoder 比较器"
```

---

### Task 7: Cross-Encoder 比较器

**Files:**
- Create: `src/evel/comparators/cross_encoder.py`
- Create: `tests/evel/test_cross_encoder.py`

- [ ] **Step 1: 创建测试 `tests/evel/test_cross_encoder.py`**

```python
import pytest
from unittest.mock import patch, MagicMock
from evel.comparators.cross_encoder import CrossEncoderComparator

def test_cross_encoder_pass():
    comparator = CrossEncoderComparator(
        api_url="http://api.example.com/reranker",
        model_name="Qwen3-Reranker-4B",
        pass_threshold=0.85
    )

    mock_response = MagicMock()
    mock_response.json.return_value = {"score": 0.90}

    with patch('requests.post', return_value=mock_response):
        result = comparator.compare("苹果", "苹果")

    assert result.is_match is True
    assert result.score == 0.90
    assert result.method == "cross_encoder"

def test_cross_encoder_fail():
    comparator = CrossEncoderComparator(
        api_url="http://api.example.com/reranker",
        model_name="Qwen3-Reranker-4B",
        pass_threshold=0.85
    )

    mock_response = MagicMock()
    mock_response.json.return_value = {"score": 0.50}

    with patch('requests.post', return_value=mock_response):
        result = comparator.compare("苹果", "香蕉")

    assert result.is_match is False
    assert result.score == 0.50
    assert result.method == "cross_encoder"
```

- [ ] **Step 2: 运行测试验证失败**

Run: `pytest tests/evel/test_cross_encoder.py -v`
Expected: FAIL

- [ ] **Step 3: 实现 `src/evel/comparators/cross_encoder.py`**

```python
"""Cross-Encoder 评分比较器"""
from dataclasses import dataclass
from typing import Optional
import requests


@dataclass
class CompareResult:
    """比较结果"""
    is_match: bool
    method: str
    score: Optional[float] = None
    reason: Optional[str] = None


class CrossEncoderComparator:
    """Cross-Encoder 评分比较器"""

    def __init__(
        self,
        api_url: str,
        model_name: str,
        pass_threshold: float = 0.85,
        timeout: int = 30
    ):
        self.api_url = api_url
        self.model_name = model_name
        self.pass_threshold = pass_threshold
        self.timeout = timeout

    def compare(self, man: str, model: str) -> CompareResult:
        """
        比较两个答案的 Cross-Encoder 评分
        """
        try:
            response = requests.post(
                self.api_url,
                json={"text1": man, "text2": model, "model": self.model_name},
                timeout=self.timeout
            )
            response.raise_for_status()
            data = response.json()
            score = data["score"]
        except Exception:
            return CompareResult(is_match=False, method="cross_encoder_error", score=0.0)

        if score >= self.pass_threshold:
            return CompareResult(is_match=True, method="cross_encoder", score=score)
        else:
            return CompareResult(is_match=False, method="cross_encoder", score=score)
```

- [ ] **Step 4: 运行测试验证通过**

Run: `pytest tests/evel/test_cross_encoder.py -v`
Expected: PASS

- [ ] **Step 5: 提交**

```bash
git add src/evel/comparators/cross_encoder.py tests/evel/test_cross_encoder.py
git commit -m "feat: 添加 Cross-Encoder 比较器"
```

---

### Task 8: LLM 兜底判定器

**Files:**
- Create: `src/evel/comparators/llm_judge.py`
- Create: `tests/evel/test_llm_judge.py`

- [ ] **Step 1: 创建测试 `tests/evel/test_llm_judge.py`**

```python
import pytest
from unittest.mock import patch, MagicMock
from evel.comparators.llm_judge import LLMJudgeComparator

def test_llm_judge_correct():
    comparator = LLMJudgeComparator(
        api_url="http://api.example.com/llm",
        model_name="team-llm",
        timeout=30
    )

    mock_response = MagicMock()
    mock_response.json.return_value = {"result": "correct", "reason": "语义一致"}

    with patch('requests.post', return_value=mock_response):
        result = comparator.compare("苹果", "苹果")

    assert result.is_match is True
    assert result.reason == "语义一致"

def test_llm_judge_incorrect():
    comparator = LLMJudgeComparator(
        api_url="http://api.example.com/llm",
        model_name="team-llm",
        timeout=30
    )

    mock_response = MagicMock()
    mock_response.json.return_value = {"result": "incorrect", "reason": "语义不符"}

    with patch('requests.post', return_value=mock_response):
        result = comparator.compare("苹果", "火车")

    assert result.is_match is False
    assert result.reason == "语义不符"
```

- [ ] **Step 2: 运行测试验证失败**

Run: `pytest tests/evel/test_llm_judge.py -v`
Expected: FAIL

- [ ] **Step 3: 实现 `src/evel/comparators/llm_judge.py`**

```python
"""LLM 兜底判定器"""
from dataclasses import dataclass
from typing import Optional
import requests


@dataclass
class CompareResult:
    """比较结果"""
    is_match: bool
    method: str
    score: Optional[float] = None
    reason: Optional[str] = None


class LLMJudgeComparator:
    """LLM 兜底判定器"""

    def __init__(
        self,
        api_url: str,
        model_name: str,
        timeout: int = 30
    ):
        self.api_url = api_url
        self.model_name = model_name
        self.timeout = timeout

    def compare(self, man: str, model: str) -> CompareResult:
        """
        使用 LLM 判定两个答案是否语义一致
        """
        try:
            response = requests.post(
                self.api_url,
                json={
                    "model": self.model_name,
                    "prompt": f"判断以下两个答案是否语义一致：\n答案1: {man}\n答案2: {model}",
                    "temperature": 0.0
                },
                timeout=self.timeout
            )
            response.raise_for_status()
            data = response.json()
            result = data.get("result", "").lower()
            is_match = "correct" in result or "一致" in result or "是" in result
            reason = data.get("reason", "")
        except Exception as e:
            return CompareResult(
                is_match=False,
                method="llm_judge_error",
                reason=str(e)
            )

        return CompareResult(
            is_match=is_match,
            method="llm_judge",
            reason=reason
        )
```

- [ ] **Step 4: 运行测试验证通过**

Run: `pytest tests/evel/test_llm_judge.py -v`
Expected: PASS

- [ ] **Step 5: 提交**

```bash
git add src/evel/comparators/llm_judge.py tests/evel/test_llm_judge.py
git commit -m "feat: 添加 LLM 兜底判定器"
```

---

### Task 9: 主评测引擎

**Files:**
- Create: `src/evel/evaluator.py`
- Create: `tests/evel/test_evaluator.py`

- [ ] **Step 1: 创建测试 `tests/evel/test_evaluator.py`**

```python
import pytest
from unittest.mock import MagicMock, patch
from evel.evaluator import Evaluator

def test_evaluator_exact_match():
    config = MagicMock()
    config.thresholds = {
        "literal_pass": 0.95,
        "literal_fail": 0.30,
        "cross_encoder_pass": 0.85,
        "bi_encoder_pass": 0.95,
        "bi_encoder_fail": 0.30,
        "llm_fallback_enabled": False,
    }
    config.models = {}
    config.llm = {}
    config.synonym = {"dict_path": "synonym/synonym.txt"}
    config.fields = ["要素"]

    evaluator = Evaluator(config)

    result = evaluator.evaluate_single("苹果", "苹果")
    assert result.is_match is True
    assert result.method == "exact_match"

def test_evaluator_literal_gray_zone_calls_cross_encoder():
    config = MagicMock()
    config.thresholds = {
        "literal_pass": 0.95,
        "literal_fail": 0.30,
        "cross_encoder_pass": 0.85,
        "bi_encoder_pass": 0.95,
        "bi_encoder_fail": 0.30,
        "llm_fallback_enabled": False,
    }
    config.models = {
        "cross_encoder_api_url": "http://api.example.com/reranker",
        "cross_encoder_model": "Qwen3-Reranker-4B",
    }
    config.llm = {}
    config.synonym = {"dict_path": "synonym/synonym.txt"}
    config.fields = ["要素"]

    evaluator = Evaluator(config)

    # "苹果" vs "苹果手机" - 字面相似度在灰区
    mock_response = MagicMock()
    mock_response.json.return_value = {"score": 0.90}

    with patch('evel.comparators.cross_encoder.requests.post', return_value=mock_response):
        result = evaluator.evaluate_single("苹果", "苹果手机")

    assert result.is_match is True
    assert result.method == "cross_encoder"
```

- [ ] **Step 2: 运行测试验证失败**

Run: `pytest tests/evel/test_evaluator.py -v`
Expected: FAIL

- [ ] **Step 3: 实现 `src/evel/evaluator.py`**

```python
"""主评测引擎"""
from dataclasses import dataclass
from typing import Optional, Tuple
from .comparators.exact_match import ExactMatchComparator
from .comparators.synonym import SynonymComparator
from .comparators.literal import LiteralComparator
from .comparators.bi_encoder import BiEncoderComparator
from .comparators.cross_encoder import CrossEncoderComparator
from .comparators.llm_judge import LLMJudgeComparator


@dataclass
class CompareResult:
    """比较结果"""
    is_match: bool
    method: str
    score: Optional[float] = None
    reason: Optional[str] = None


class Evaluator:
    """主评测引擎"""

    def __init__(self, config):
        self.config = config
        self.thresholds = config.thresholds
        self.models = config.models
        self.llm_config = config.llm

        # 初始化比较器
        self.exact_match = ExactMatchComparator()
        self.synonym = SynonymComparator(config.synonym["dict_path"])
        self.literal = LiteralComparator(
            pass_threshold=self.thresholds["literal_pass"],
            fail_threshold=self.thresholds["literal_fail"]
        )
        self.bi_encoder = BiEncoderComparator(
            api_url=self.models["bi_encoder_api_url"],
            model_name=self.models["bi_encoder_model"],
            pass_threshold=self.thresholds["bi_encoder_pass"],
            fail_threshold=self.thresholds["bi_encoder_fail"]
        )
        self.cross_encoder = CrossEncoderComparator(
            api_url=self.models["cross_encoder_api_url"],
            model_name=self.models["cross_encoder_model"],
            pass_threshold=self.thresholds["cross_encoder_pass"]
        )
        self.llm_judge = LLMJudgeComparator(
            api_url=self.llm_config["api_url"],
            model_name=self.llm_config["model_name"],
            timeout=self.llm_config.get("timeout", 30)
        ) if config.llm_fallback_enabled else None

    @staticmethod
    def count_chars(text: str) -> int:
        """计算字数（中文按字符数，英文按单词数）"""
        import re
        chinese_chars = len(re.findall(r'[一-鿿]', text))
        english_words = len(re.findall(r'[a-zA-Z]+', text))
        return chinese_chars + english_words

    def evaluate_single(self, man: str, model: str) -> CompareResult:
        """
        对单对答案进行评测
        """
        # Step 1: 完全一致检查
        result = self.exact_match.compare(man, model)
        if result.is_match:
            return result

        # Step 2: 同义词检查
        result = self.synonym.compare(man, model)
        if result.is_match:
            return result

        # Step 3: 字数判断
        char_count = self.count_chars(man) if not self._is_english_words(man) else self.count_chars(man)

        if char_count < 3:
            return self._evaluate_short(man, model)
        else:
            return self._evaluate_long(man, model)

    def _is_english_words(self, text: str) -> bool:
        """判断是否为英文单词文本"""
        import re
        chinese_chars = len(re.findall(r'[一-鿿]', text))
        return chinese_chars == 0 and len(re.findall(r'[a-zA-Z]+', text)) > 0

    def _evaluate_short(self, man: str, model: str) -> CompareResult:
        """评测短文本（< 3字或单词数 < 3）"""
        # 字面相似度
        result = self.literal.compare(man, model)
        if result.is_match:
            return result
        if result.method == "literal_fail":
            return result

        # 灰区: Cross-Encoder
        return self.cross_encoder.compare(man, model)

    def _evaluate_long(self, man: str, model: str) -> CompareResult:
        """评测长文本（>= 3字或单词数 >= 3）"""
        # Bi-Encoder 相似度
        result = self.bi_encoder.compare(man, model)
        if result.is_match or result.method == "bi_encoder_fail":
            return result

        # 灰区: Cross-Encoder
        result = self.cross_encoder.compare(man, model)
        if result.is_match:
            return result

        # LLM 兜底
        if self.llm_judge:
            return self.llm_judge.compare(man, model)

        return result
```

- [ ] **Step 4: 运行测试验证通过**

Run: `pytest tests/evel/test_evaluator.py -v`
Expected: PASS

- [ ] **Step 5: 提交**

```bash
git add src/evel/evaluator.py tests/evel/test_evaluator.py
git commit -m "feat: 添加主评测引擎"
```

---

### Task 10: Excel 输出生成模块

**Files:**
- Create: `src/evel/output.py`
- Create: `tests/evel/test_output.py`

- [ ] **Step 1: 创建测试 `tests/evel/test_output.py`**

```python
import tempfile
import os
from openpyxl import load_workbook
from evel.output import OutputGenerator

def test_output_generator():
    # 创建测试输入 Excel
    input_data = [
        {"文件名": "doc1", "要素_man": "苹果", "要素_model": "苹果", "条款_man": "合同", "条款_model": "协议"},
        {"文件名": "doc2", "要素_man": "苹果", "要素_model": "香蕉", "条款_man": "合同", "条款_model": "合同"},
    ]

    results = {
        "要素": [
            {"is_match": True, "method": "exact_match"},
            {"is_match": False, "method": "literal_fail"},
        ],
        "条款": [
            {"is_match": True, "method": "synonym"},
            {"is_match": True, "method": "exact_match"},
        ],
    }

    generator = OutputGenerator(input_data, results)
    output_path = tempfile.mktemp(suffix='.xlsx')

    try:
        accuracy, details = generator.generate(output_path)

        # 验证返回结构
        assert isinstance(accuracy, float)
        assert 0.0 <= accuracy <= 1.0
        assert "要素" in details
        assert "条款" in details

        # 验证 Excel 文件
        wb = load_workbook(output_path)
        assert "Sheet1" in wb.sheetnames
        assert "统计汇总" in wb.sheetnames
    finally:
        if os.path.exists(output_path):
            os.unlink(output_path)
```

- [ ] **Step 2: 运行测试验证失败**

Run: `pytest tests/evel/test_output.py -v`
Expected: FAIL

- [ ] **Step 3: 实现 `src/evel/output.py`**

```python
"""Excel 输出生成模块"""
from typing import Dict, List, Any, Tuple
from openpyxl import Workbook


class OutputGenerator:
    """Excel 输出生成器"""

    def __init__(self, input_data: List[Dict], results: Dict[str, List[Dict]]):
        self.input_data = input_data
        self.results = results

    def generate(self, output_path: str) -> Tuple[float, Dict[str, Dict]]:
        """
        生成输出 Excel 文件
        返回: (总体正确率, 各字段统计详情)
        """
        wb = Workbook()

        # Sheet 1: 原始数据扩展
        ws1 = wb.active
        ws1.title = "Sheet1"

        # 构建表头
        headers = list(self.input_data[0].keys()) if self.input_data else []
        for field in self.results.keys():
            headers.append(f"{field}_result")
            headers.append(f"{field}_method")

        ws1.append(headers)

        # 填充数据
        for idx, row in enumerate(self.input_data):
            row_data = list(row.values())
            for field, field_results in self.results.items():
                if idx < len(field_results):
                    r = field_results[idx]
                    row_data.append("✅" if r["is_match"] else "❌")
                    row_data.append(r["method"])
                else:
                    row_data.append("")
                    row_data.append("")
            ws1.append(row_data)

        # Sheet 2: 统计汇总
        ws2 = wb.create_sheet("统计汇总")
        ws2.append(["字段名", "正确数", "总数", "正确率"])

        details = {}
        total_correct = 0
        total_count = 0

        for field, field_results in self.results.items():
            correct = sum(1 for r in field_results if r["is_match"])
            total = len(field_results)
            accuracy = correct / total if total > 0 else 0.0
            total_correct += correct
            total_count += total
            details[field] = {"correct": correct, "total": total, "accuracy": accuracy}
            ws2.append([field, correct, total, f"{accuracy:.1%}"])

        overall_accuracy = total_correct / total_count if total_count > 0 else 0.0
        ws2.append(["总体", total_correct, total_count, f"{overall_accuracy:.1%}"])

        wb.save(output_path)

        return overall_accuracy, details
```

- [ ] **Step 4: 运行测试验证通过**

Run: `pytest tests/evel/test_output.py -v`
Expected: PASS

- [ ] **Step 5: 提交**

```bash
git add src/evel/output.py tests/evel/test_output.py
git commit -m "feat: 添加 Excel 输出生成模块"
```

---

### Task 11: 主入口文件

**Files:**
- Create: `src/evel/__main__.py`
- Create: `tests/evel/test_integration.py`

- [ ] **Step 1: 创建测试 `tests/evel/test_integration.py`**

```python
import tempfile
import os
from openpyxl import Workbook
from evel import evaluate

def test_evaluate_integration():
    # 创建测试输入 Excel
    wb = Workbook()
    ws = wb.active
    ws.append(["文件名", "要素_man", "要素_model", "条款_man", "条款_model"])
    ws.append(["doc1", "苹果", "苹果", "合同", "合同"])
    ws.append(["doc2", "苹果", "香蕉", "合同", "协议"])

    input_path = tempfile.mktemp(suffix='.xlsx')
    wb.save(input_path)

    # 创建临时配置
    import tempfile
    config_content = """
[thresholds]
literal_pass = 0.95
literal_fail = 0.30
cross_encoder_pass = 0.85
bi_encoder_pass = 0.95
bi_encoder_fail = 0.30
llm_fallback_enabled = false

[models]
bi_encoder_model = "Qwen3-Embedding-4B"
bi_encoder_api_url = "http://api.example.com/embedding"
cross_encoder_model = "Qwen3-Reranker-4B"
cross_encoder_api_url = "http://api.example.com/reranker"

[llm]
api_url = "http://api.example.com/llm"
model_name = "team-llm"
timeout = 30

[synonym]
dict_path = "synonym/synonym.txt"

[fields]
evaluate = ["要素", "条款"]
"""
    config_path = tempfile.mktemp(suffix='.toml')
    with open(config_path, 'w') as f:
        f.write(config_content)

    output_path = tempfile.mktemp(suffix='.xlsx')

    try:
        result = evaluate(input_path, config_path, output_path)

        assert "total_accuracy" in result
        assert "details" in result
        assert os.path.exists(output_path)
    finally:
        for p in [input_path, config_path, output_path]:
            if os.path.exists(p):
                os.unlink(p)
```

- [ ] **Step 2: 运行测试验证失败**

Run: `pytest tests/evel/test_integration.py -v`
Expected: FAIL

- [ ] **Step 3: 实现 `src/evel/__main__.py`**

```python
"""evel - 自动评测工具 主入口"""
import sys
from typing import Dict, Any
from openpyxl import load_workbook
from .config import Config
from .evaluator import Evaluator
from .output import OutputGenerator


def evaluate(input_path: str, config_path: str, output_path: str) -> Dict[str, Any]:
    """
    主评测函数

    Args:
        input_path: 输入 Excel 路径
        config_path: TOML 配置文件路径
        output_path: 输出 Excel 路径

    Returns:
        {
            "total_accuracy": float,
            "sheet1_path": str,
            "details": Dict
        }
    """
    # 加载配置
    config = Config(config_path)

    # 加载输入 Excel
    wb = load_workbook(input_path)
    ws = wb.active

    # 提取表头和数据
    headers = [cell.value for cell in ws[1]]
    rows = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if any(cell is not None for cell in row):
            rows.append(dict(zip(headers, row)))

    # 初始化评测引擎
    evaluator = Evaluator(config)

    # 对每个字段进行评测
    results = {}
    for field in config.fields:
        man_key = f"{field}_man"
        model_key = f"{field}_model"

        field_results = []
        for row in rows:
            man = str(row.get(man_key, ""))
            model = str(row.get(model_key, ""))
            result = evaluator.evaluate_single(man, model)
            field_results.append({
                "is_match": result.is_match,
                "method": result.method,
                "score": result.score,
                "reason": result.reason
            })
        results[field] = field_results

    # 生成输出
    generator = OutputGenerator(rows, results)
    total_accuracy, details = generator.generate(output_path)

    return {
        "total_accuracy": total_accuracy,
        "sheet1_path": output_path,
        "details": details
    }


def main():
    if len(sys.argv) != 4:
        print("用法: python -m evel <input.xlsx> <config.toml> <output.xlsx>")
        sys.exit(1)

    input_path = sys.argv[1]
    config_path = sys.argv[2]
    output_path = sys.argv[3]

    result = evaluate(input_path, config_path, output_path)
    print(f"评测完成！总体正确率: {result['total_accuracy']:.1%}")
    print(f"输出文件: {result['sheet1_path']}")


if __name__ == "__main__":
    main()
```

- [ ] **Step 4: 更新 `src/evel/__init__.py` 导出 evaluate 函数**

```python
"""evel - 自动评测工具"""
__version__ = "0.1.0"

from .evaluator import Evaluator
from .output import OutputGenerator
from .config import Config

__all__ = ["Evaluator", "OutputGenerator", "Config", "evaluate"]
```

- [ ] **Step 5: 更新 `src/evel/__init__.py`**

```python
"""evel - 自动评测工具"""
__version__ = "0.1.0"

from . import evaluator
from . import output
from . import config
from .evaluator import Evaluator
from .output import OutputGenerator
from .config import Config

__all__ = ["evaluate", "Evaluator", "OutputGenerator", "Config"]
```

- [ ] **Step 6: 更新 `src/evel/__init__.py` 添加 evaluate 函数**

```python
"""evel - 自动评测工具"""
__version__ = "0.1.0"

from . import evaluator as evaluator_module
from . import output as output_module
from . import config
from .config import Config
from .evaluator import Evaluator
from .output import OutputGenerator


def evaluate(input_path: str, config_path: str, output_path: str):
    """主评测函数"""
    import sys
    from openpyxl import load_workbook

    config_obj = Config(config_path)
    wb = load_workbook(input_path)
    ws = wb.active
    headers = [cell.value for cell in ws[1]]
    rows = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if any(cell is not None for cell in row):
            rows.append(dict(zip(headers, row)))

    evaluator = Evaluator(config_obj)
    results = {}

    for field in config_obj.fields:
        man_key = f"{field}_man"
        model_key = f"{field}_model"
        field_results = []
        for row in rows:
            man = str(row.get(man_key, ""))
            model = str(row.get(model_key, ""))
            result = evaluator.evaluate_single(man, model)
            field_results.append({
                "is_match": result.is_match,
                "method": result.method,
            })
        results[field] = field_results

    generator = OutputGenerator(rows, results)
    total_accuracy, details = generator.generate(output_path)

    return {
        "total_accuracy": total_accuracy,
        "sheet1_path": output_path,
        "details": details
    }


__all__ = ["evaluate", "Evaluator", "OutputGenerator", "Config"]
```

- [ ] **Step 7: 运行测试验证通过**

Run: `pytest tests/evel/test_integration.py -v`
Expected: PASS

- [ ] **Step 8: 提交**

```bash
git add src/evel/__main__.py src/evel/__init__.py tests/evel/test_integration.py
git commit -m "feat: 添加主入口文件"
```

---

### Task 12: 最终验证

- [ ] **Step 1: 运行所有测试**

Run: `pytest tests/ -v`
Expected: 全部 PASS

- [ ] **Step 2: 验证项目结构**

Run: `find . -type f -name "*.py" | grep -v __pycache__ | sort`
Expected: 包含所有创建的文件

- [ ] **Step 3: 提交最终变更**

```bash
git add -A
git commit -m "feat: 完成自动评测工具核心功能"
```

---

## 自检清单

1. **Spec 覆盖检查**:
   - [x] 项目结构
   - [x] TOML 配置加载
   - [x] 同义词词典格式
   - [x] 评测流程（分层判定）
   - [x] 输入 Excel 格式
   - [x] 输出双 Sheet Excel
   - [x] 接口返回值包含 total_accuracy

2. **占位符扫描**: 无 TBD/TODO/未完成部分

3. **类型一致性**: 所有 CompareResult 使用统一的 dataclass，所有方法返回 is_match + method
