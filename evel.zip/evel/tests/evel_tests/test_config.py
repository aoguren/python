import tempfile
import os
from evel.config import Config

def test_config_load():
    config_content = """
[thresholds]
literal_pass = 0.95
literal_fail = 0.30
cross_encoder_pass = 0.85
bi_encoder_pass = 0.95
bi_encoder_fail = 0.30
llm_fallback_enabled = true

[models]
bi_encoder_model = "Qwen3-Embedding-4B"
bi_encoder_api_url = "http://api.example.com/embedding"
cross_encoder_model = "Qwen3-Reranker-4B"
cross_encoder_api_url = "http://api.example.com/reranker"

[llm]
api_url = "http://api.example.com/llm"
model_name = "team-llm"
timeout = 30

[synonym]
dict_path = "synonym/synonym.txt"

[fields]
evaluate = ["要素", "条款"]
"""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.toml', delete=False, encoding='utf-8') as f:
        f.write(config_content)
        config_path = f.name

    try:
        config = Config(config_path)
        assert config.thresholds["literal_pass"] == 0.95
        assert config.thresholds["literal_fail"] == 0.30
        assert config.models["bi_encoder_api_url"] == "http://api.example.com/embedding"
        assert config.fields == ["要素", "条款"]
        assert config.llm_fallback_enabled is True
    finally:
        os.unlink(config_path)
