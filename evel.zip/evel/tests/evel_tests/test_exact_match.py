from evel.comparators.exact_match import ExactMatchComparator

def test_exact_match_positive():
    comparator = ExactMatchComparator()
    result = comparator.compare("苹果", "苹果")
    assert result.is_match is True
    assert result.method == "exact_match"

def test_exact_match_negative():
    comparator = ExactMatchComparator()
    result = comparator.compare("苹果", "香蕉")
    assert result.is_match is False
    assert result.method == "exact_match"

def test_exact_match_with_whitespace():
    comparator = ExactMatchComparator()
    # 严格字符串匹配，有空格则不匹配
    result = comparator.compare("苹果 ", "苹果")
    assert result.is_match is False
    result_stripped = comparator.compare("苹果", "苹果 ")
    assert result_stripped.is_match is False
    # 完全一致才匹配
    result_exact = comparator.compare("苹果", "苹果")
    assert result_exact.is_match is True
