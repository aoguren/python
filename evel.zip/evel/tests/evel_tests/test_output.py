import tempfile
import os
from openpyxl import load_workbook
from evel.output import OutputGenerator

def test_output_generator():
    # 创建测试输入 Excel
    input_data = [
        {"文件名": "doc1", "要素_man": "苹果", "要素_model": "苹果", "条款_man": "合同", "条款_model": "协议"},
        {"文件名": "doc2", "要素_man": "苹果", "要素_model": "香蕉", "条款_man": "合同", "条款_model": "合同"},
    ]

    results = {
        "要素": [
            {"is_match": True, "method": "exact_match"},
            {"is_match": False, "method": "literal_fail"},
        ],
        "条款": [
            {"is_match": True, "method": "synonym"},
            {"is_match": True, "method": "exact_match"},
        ],
    }

    generator = OutputGenerator(input_data, results)
    output_path = tempfile.mktemp(suffix='.xlsx')

    try:
        accuracy, details = generator.generate(output_path)

        # 验证返回结构
        assert isinstance(accuracy, float)
        assert 0.0 <= accuracy <= 1.0
        assert "要素" in details
        assert "条款" in details

        # 验证 Excel 文件
        wb = load_workbook(output_path)
        assert "Sheet1" in wb.sheetnames
        assert "统计汇总" in wb.sheetnames
    finally:
        if os.path.exists(output_path):
            os.unlink(output_path)
