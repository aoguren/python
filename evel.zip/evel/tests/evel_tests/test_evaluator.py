import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch
from evel.evaluator import Evaluator

def test_evaluator_exact_match():
    config = MagicMock()
    config.thresholds = {
        "literal_pass": 0.95,
        "literal_fail": 0.30,
        "cross_encoder_pass": 0.85,
        "bi_encoder_pass": 0.95,
        "bi_encoder_fail": 0.30,
        "llm_fallback_enabled": False,
    }
    config.models = {
        "bi_encoder": {
            "api_url": "http://api.example.com/embedding",
            "name": "Qwen3-Embedding-4B",
            "api_key": "",
        },
        "cross_encoder": {
            "api_url": "http://api.example.com/reranker",
            "name": "Qwen3-Reranker-4B",
            "api_key": "",
        },
    }
    config.llm = {}
    config.synonym = {"dict_path": "synonym/synonym.txt"}
    config.fields = ["要素"]
    config.config_dir = Path("e:/project/evel").resolve()

    evaluator = Evaluator(config)

    result = evaluator.evaluate_single("苹果", "苹果")
    assert result.is_match is True
    assert result.method == "exact_match"

def test_evaluator_literal_gray_zone_calls_cross_encoder():
    config = MagicMock()
    config.thresholds = {
        "literal_pass": 0.95,
        "literal_fail": 0.30,
        "cross_encoder_pass": 0.85,
        "bi_encoder_pass": 0.95,
        "bi_encoder_fail": 0.30,
        "llm_fallback_enabled": False,
    }
    config.models = {
        "bi_encoder": {
            "api_url": "http://api.example.com/embedding",
            "name": "Qwen3-Embedding-4B",
            "api_key": "",
        },
        "cross_encoder": {
            "api_url": "http://api.example.com/reranker",
            "name": "Qwen3-Reranker-4B",
            "api_key": "",
        },
    }
    config.llm = {}
    config.synonym = {"dict_path": "synonym/synonym.txt"}
    config.fields = ["要素"]
    config.config_dir = Path("e:/project/evel").resolve()

    evaluator = Evaluator(config)

    # "苹果" vs "苹果手机" - 字面相似度在灰区
    mock_response = MagicMock()
    mock_response.json.return_value = {"score": 0.90}

    with patch('evel.comparators.cross_encoder.requests.post', return_value=mock_response):
        result = evaluator.evaluate_single("苹果", "苹果手机")

    assert result.is_match is True
    assert result.method == "cross_encoder"
