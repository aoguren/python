import tempfile
import os
from openpyxl import Workbook
from evel import evaluate

def test_evaluate_integration():
    # 创建测试输入 Excel
    wb = Workbook()
    ws = wb.active
    ws.append(["文件名", "要素_man", "要素_model", "条款_man", "条款_model"])
    ws.append(["doc1", "苹果", "苹果", "合同", "合同"])
    ws.append(["doc2", "苹果", "香蕉", "合同", "协议"])

    input_path = tempfile.mktemp(suffix='.xlsx')
    wb.save(input_path)

    # 创建临时配置
    config_content = """
[thresholds]
literal_pass = 0.95
literal_fail = 0.30
cross_encoder_pass = 0.85
bi_encoder_pass = 0.95
bi_encoder_fail = 0.30
llm_fallback_enabled = false

[models]
bi_encoder_model = "Qwen3-Embedding-4B"
bi_encoder_api_url = "http://api.example.com/embedding"
cross_encoder_model = "Qwen3-Reranker-4B"
cross_encoder_api_url = "http://api.example.com/reranker"

[llm]
api_url = "http://api.example.com/llm"
model_name = "team-llm"
timeout = 30

[synonym]
dict_path = "synonym/synonym.txt"

[fields]
evaluate = ["要素", "条款"]
"""
    config_path = tempfile.mktemp(suffix='.toml')
    with open(config_path, 'w', encoding='utf-8') as f:
        f.write(config_content)

    output_path = tempfile.mktemp(suffix='.xlsx')

    try:
        result = evaluate(input_path, config_path, output_path)

        assert "total_accuracy" in result
        assert "details" in result
        assert os.path.exists(output_path)
    finally:
        for p in [input_path, config_path, output_path]:
            if os.path.exists(p):
                os.unlink(p)
