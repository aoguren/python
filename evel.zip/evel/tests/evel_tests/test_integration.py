import tempfile
import os
from pathlib import Path
from openpyxl import Workbook
from evel import evaluate

def test_evaluate_integration():
    # 创建测试输入 Excel
    wb = Workbook()
    ws = wb.active
    ws.append(["文件名", "要素_man", "要素_model", "条款_man", "条款_model"])
    ws.append(["doc1", "苹果", "苹果", "合同", "合同"])
    ws.append(["doc2", "苹果", "香蕉", "合同", "协议"])

    input_path = tempfile.mktemp(suffix='.xlsx')
    wb.save(input_path)

    # 使用项目根目录的绝对路径（TOML 需要用正斜杠）
    project_root = Path("e:/project/evel").resolve()
    synonym_path = (project_root / "synonym" / "synonym.txt").as_posix()

    # 创建临时配置
    config_content = f"""
[thresholds]
literal_pass = 0.95
literal_fail = 0.30
cross_encoder_pass = 0.85
bi_encoder_pass = 0.95
bi_encoder_fail = 0.30
llm_fallback_enabled = false

[models.bi_encoder]
name = "Qwen3-Embedding-4B"
api_url = "http://api.example.com/embedding"
api_key = ""

[models.cross_encoder]
name = "Qwen3-Reranker-4B"
api_url = "http://api.example.com/reranker"
api_key = ""

[llm]
api_url = "http://api.example.com/llm"
model_name = "team-llm"
api_key = ""
timeout = 30

[synonym]
dict_path = "{synonym_path}"

[fields]
evaluate = ["要素", "条款"]
"""
    config_path = tempfile.mktemp(suffix='.toml')
    with open(config_path, 'w', encoding='utf-8') as f:
        f.write(config_content)

    output_path = tempfile.mktemp(suffix='.xlsx')

    try:
        result = evaluate(input_path, config_path, output_path)

        assert "total_accuracy" in result
        assert "details" in result
        assert os.path.exists(output_path)
    finally:
        for p in [input_path, config_path, output_path]:
            if os.path.exists(p):
                os.unlink(p)
