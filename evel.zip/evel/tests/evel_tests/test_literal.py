from evel.comparators.literal import LiteralComparator

def test_literal_match_high_similarity():
    comparator = LiteralComparator(pass_threshold=0.95, fail_threshold=0.30)
    result = comparator.compare("苹果", "苹果")
    assert result.is_match is True
    assert result.score == 1.0
    assert result.method == "literal_match"

def test_literal_fail_low_similarity():
    comparator = LiteralComparator(pass_threshold=0.95, fail_threshold=0.30)
    result = comparator.compare("苹果", "香蕉")
    assert result.is_match is False
    assert result.score < 0.30
    assert result.method == "literal_fail"

def test_literal_gray_zone():
    comparator = LiteralComparator(pass_threshold=0.95, fail_threshold=0.30)
    result = comparator.compare("苹果", "苹雇")
    # 编辑距离 0.5 在灰区
    assert 0.30 < result.score < 0.95
    assert result.is_match is False
    assert result.method == "literal_gray"
