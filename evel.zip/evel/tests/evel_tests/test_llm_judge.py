import pytest
from unittest.mock import patch, MagicMock
from evel.comparators.llm_judge import LLMJudgeComparator

def test_llm_judge_correct():
    comparator = LLMJudgeComparator(
        api_url="http://api.example.com/llm",
        model_name="team-llm",
        timeout=30
    )

    mock_response = MagicMock()
    mock_response.json.return_value = {"result": "correct", "reason": "语义一致"}

    with patch('evel.comparators.llm_judge.requests.post', return_value=mock_response):
        result = comparator.compare("苹果", "苹果")

    assert result.is_match is True
    assert result.reason == "语义一致"

def test_llm_judge_incorrect():
    comparator = LLMJudgeComparator(
        api_url="http://api.example.com/llm",
        model_name="team-llm",
        timeout=30
    )

    mock_response = MagicMock()
    mock_response.json.return_value = {"result": "incorrect", "reason": "语义不符"}

    with patch('evel.comparators.llm_judge.requests.post', return_value=mock_response):
        result = comparator.compare("苹果", "火车")

    assert result.is_match is False
    assert result.reason == "语义不符"
