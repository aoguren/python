import tempfile
import os
from evel.comparators.synonym import SynonymComparator

def test_synonym_match():
    # 创建测试词典
    dict_content = "苹果 手机 移动电话\n电脑 计算机 PC"
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False, encoding='utf-8') as f:
        f.write(dict_content)
        dict_path = f.name

    try:
        comparator = SynonymComparator(dict_path)
        result = comparator.compare("苹果", "手机")
        assert result.is_match is True
        assert result.method == "synonym"
    finally:
        os.unlink(dict_path)

def test_synonym_no_match():
    dict_content = "苹果 手机\n电脑 计算机"
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False, encoding='utf-8') as f:
        f.write(dict_content)
        dict_path = f.name

    try:
        comparator = SynonymComparator(dict_path)
        result = comparator.compare("苹果", "电脑")
        assert result.is_match is False
        assert result.method == "synonym"
    finally:
        os.unlink(dict_path)

def test_synonym_not_in_dict():
    dict_content = "苹果 手机"
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False, encoding='utf-8') as f:
        f.write(dict_content)
        dict_path = f.name

    try:
        comparator = SynonymComparator(dict_path)
        result = comparator.compare("香蕉", "苹果")
        assert result.is_match is False
    finally:
        os.unlink(dict_path)
