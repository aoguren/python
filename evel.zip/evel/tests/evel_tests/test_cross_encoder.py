import pytest
from unittest.mock import patch, MagicMock
from evel.comparators.cross_encoder import CrossEncoderComparator

def test_cross_encoder_pass():
    comparator = CrossEncoderComparator(
        api_url="http://api.example.com/reranker",
        model_name="Qwen3-Reranker-4B",
        pass_threshold=0.85
    )

    mock_response = MagicMock()
    mock_response.json.return_value = {"score": 0.90}

    with patch('requests.post', return_value=mock_response):
        result = comparator.compare("苹果", "苹果")

    assert result.is_match is True
    assert result.score == 0.90
    assert result.method == "cross_encoder"

def test_cross_encoder_fail():
    comparator = CrossEncoderComparator(
        api_url="http://api.example.com/reranker",
        model_name="Qwen3-Reranker-4B",
        pass_threshold=0.85
    )

    mock_response = MagicMock()
    mock_response.json.return_value = {"score": 0.50}

    with patch('requests.post', return_value=mock_response):
        result = comparator.compare("苹果", "香蕉")

    assert result.is_match is False
    assert result.score == 0.50
    assert result.method == "cross_encoder"
