import requests
import json

response = requests.post(
  url="https://openrouter.ai/api/v1/embeddings",
  headers={
    "Authorization": "Bearer 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",
    "Content-Type": "application/json",
   
  },
  data=json.dumps({
    "model": "nvidia/llama-nemotron-embed-vl-1b-v2:free",
    "input": [
      {
        "content": [
          {"type": "text", "text": "What is in this image?"},
          {"type": "image_url", "image_url": {"url": "https://live.staticflickr.com/3851/14825276609_098cac593d_b.jpg"}}
        ]
      }
    ],
    "encoding_format": "float"
  })
)

print(response.json()["data"][0]["embedding"][:5])