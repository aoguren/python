#!/usr/bin/env python3
"""
质检数据查看工具 - 本地服务器
运行方式: python run_server.py
访问地址: http://localhost:8080
"""

import http.server
import socketserver
import os
import pandas as pd
import json
import math

# 加载配置文件
CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.json')
if os.path.exists(CONFIG_FILE):
    with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
        CONFIG = json.load(f)
else:
    CONFIG = {'excel_file': '质检数据.xlsx', 'port': 8080}

PORT = CONFIG.get('port', 8080)
EXCEL_FILE = CONFIG.get('excel_file', '质检数据.xlsx')

FILE_NAME_COLUMN = CONFIG.get('file_name_column', 'file_name')

def clean_json_value(val):
    """清理JSON中的NaN和Inf值"""
    if val is None:
        return None
    if isinstance(val, float) and (math.isnan(val) or math.isinf(val)):
        return None
    if isinstance(val, (int, float)):
        return val
    return str(val)

# 获取当前目录
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))

class ExcelCache:
    """Excel数据缓存"""
    _cache = None
    _columns = None
    _loaded = False

    @classmethod
    def get_data(cls):
        """获取缓存数据，如果未加载则读取Excel"""
        if not cls._loaded:
            cls._load_excel()
        return cls._cache

    @classmethod
    def get_columns(cls):
        """获取业务字段列表"""
        if not cls._loaded:
            cls._load_excel()
        return cls._columns

    @classmethod
    def _load_excel(cls):
        """读取Excel文件并缓存"""
        excel_path = os.path.join(CURRENT_DIR, EXCEL_FILE)

        if not os.path.isfile(excel_path):
            raise FileNotFoundError(f"Excel文件不存在: {excel_path}")

        try:
            df = pd.read_excel(excel_path)
        except Exception as e:
            raise RuntimeError(f"读取Excel文件失败: {str(e)}")

        if FILE_NAME_COLUMN not in df.columns:
            raise ValueError(f"Excel文件中缺少'{FILE_NAME_COLUMN}'列")

        files = df[FILE_NAME_COLUMN].unique().tolist()
        data = {}
        for file_name in files:
            records = df[df[FILE_NAME_COLUMN] == file_name].to_dict('records')
            # 清理记录中的NaN值
            cleaned_records = []
            for record in records:
                cleaned_record = {k: clean_json_value(v) for k, v in record.items()}
                cleaned_records.append(cleaned_record)
            data[file_name] = cleaned_records

        # 提取业务字段名（排除文件名字段、质检字段、备注字段）
        business_fields = [col for col in df.columns if col != FILE_NAME_COLUMN and not col.endswith('_质检') and not col.endswith('_备注')]
        cls._columns = business_fields

        cls._cache = {
            "files": files,
            "data": data
        }
        cls._loaded = True

    @classmethod
    def invalidate(cls):
        """清除缓存"""
        cls._loaded = False
        cls._cache = None


class MyHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        super().end_headers()

    def send_excel_data(self):
        try:
            result = ExcelCache.get_data()
            # 添加字段列表到结果中
            result['columns'] = ExcelCache.get_columns()
            # 添加文件名字段名到结果中
            result['file_name_column'] = FILE_NAME_COLUMN
        except FileNotFoundError as e:
            self.send_error_response(404, str(e))
            return
        except ValueError as e:
            self.send_error_response(400, str(e))
            return
        except Exception as e:
            self.send_error_response(500, f"服务器内部错误: {str(e)}")
            return

        response = json.dumps(result, ensure_ascii=False, indent=2)
        response_bytes = response.encode('utf-8')

        self.send_response(200)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', len(response_bytes))
        self.end_headers()
        self.wfile.write(response_bytes)

    def send_error_response(self, code, message):
        """发送错误响应"""
        error_response = json.dumps({"error": message}, ensure_ascii=False, indent=2)
        response_bytes = error_response.encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', len(response_bytes))
        self.end_headers()
        self.wfile.write(response_bytes)

    def do_GET(self):
        if self.path == '/':
            self.path = '/index.html'
        elif self.path == '/api/data':
            self.send_excel_data()
            return

        path = self.translate_path(self.path)
        if os.path.isfile(path):
            if path.endswith('.html') or path.endswith('.htm'):
                with open(path, 'rb') as f:
                    content = f.read()
                encoded_content = content.decode('utf-8').encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.send_header('Content-Length', len(encoded_content))
                self.end_headers()
                self.wfile.write(encoded_content)
                return

        return http.server.SimpleHTTPRequestHandler.do_GET(self)

    def do_POST(self):
        if self.path == '/api/import':
            self.handle_import()
            return
        elif self.path == '/api/reload':
            self.handle_reload()
            return
        self.send_error_response(404, "Not Found")

    def handle_reload(self):
        """重新加载Excel数据"""
        try:
            ExcelCache.invalidate()
            ExcelCache.get_data()  # 重新加载
            result = ExcelCache.get_data()
            result['columns'] = ExcelCache.get_columns()
            result['file_name_column'] = FILE_NAME_COLUMN
            response = json.dumps({
                'success': True,
                'message': '数据已重新加载',
                'files_count': len(result['files'])
            }, ensure_ascii=False)
            response_bytes = response.encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', len(response_bytes))
            self.end_headers()
            self.wfile.write(response_bytes)
        except Exception as e:
            self.send_error_response(500, f"重新加载失败: {str(e)}")

    def handle_import(self):
        """处理CSV文件导入"""
        try:
            content_length = int(self.headers.get('Content-Length', 0))
            if content_length == 0:
                self.send_error_response(400, "没有上传文件")
                return

            # 读取匹配列数配置
            match_columns = CONFIG.get('match_columns', 3)

            # 读取上传的文件内容
            body = self.rfile.read(content_length)

            # 解析CSV
            import csv
            import io
            csv_text = body.decode('utf-8-sig', errors='replace')
            reader = csv.DictReader(io.StringIO(csv_text))

            saved_data = []
            for row in reader:
                if row.get('saved') == 'true' or row.get('_saved') == 'true':
                    # 提取file_name用于定位卡片（尝试配置的字段名和备选名称）
                    file_name = row.get(FILE_NAME_COLUMN, '')
                    if not file_name:
                        # 兼容：如果配置的字段名不存在，尝试其他常见名称
                        for alt_name in ['file_name', 'fileName', 'filename']:
                            file_name = row.get(alt_name, '')
                            if file_name:
                                break
                    if file_name:
                        # 获取前N个字段值用于联合匹配（排除质检和备注字段）
                        match_values = []
                        for k, v in row.items():
                            # 跳过文件名字段、保存标记、质检字段、备注字段
                            if k in [FILE_NAME_COLUMN, 'saved', '_saved']:
                                continue
                            if k.endswith('_质检') or k.endswith('_备注'):
                                continue
                            if v:
                                match_values.append(v)
                                if len(match_values) >= match_columns:
                                    break
                        saved_data.append({
                            'file_name': file_name,
                            'row_data': {k: v for k, v in row.items() if k not in [FILE_NAME_COLUMN, 'saved', '_saved']},
                            'match_values': match_values
                        })

            response = json.dumps({
                'success': True,
                'count': len(saved_data),
                'data': saved_data
            }, ensure_ascii=False)
            response_bytes = response.encode('utf-8')

            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', len(response_bytes))
            self.end_headers()
            self.wfile.write(response_bytes)
        except Exception as e:
            self.send_error_response(500, f"导入失败: {str(e)}")

if __name__ == "__main__":
    os.chdir(CURRENT_DIR)
    with socketserver.TCPServer(("", PORT), MyHTTPRequestHandler) as httpd:
        print("=" * 50)
        print("QC Data Viewer Started")
        print("URL: http://localhost:8080")
        print("Press Ctrl+C to stop")
        print("=" * 50)
        httpd.serve_forever()